#!/usr/bin/env python3
"""Run an original local Mont recording and a same-input FFmpeg experiment."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import textwrap
import time


# Original 5x7 bitmap letterforms, drawn here rather than copied from a font.
# Lowercase transcript characters deliberately use uppercase glyphs on screen.
GLYPHS = {
    "A": "0E11111F111111", "B": "1E11111E11111E", "C": "0E11101010110E",
    "D": "1E11111111111E", "E": "1F10101E10101F", "F": "1F10101E101010",
    "G": "0E11101711110F", "H": "1111111F111111", "I": "0E04040404040E",
    "J": "0702020212120C", "K": "11121418141211", "L": "1010101010101F",
    "M": "111B1515111111", "N": "11191513111111", "O": "0E11111111110E",
    "P": "1E11111E101010", "Q": "0E11111115120D", "R": "1E11111E141211",
    "S": "0F10100E01011E", "T": "1F040404040404", "U": "1111111111110E",
    "V": "11111111110A04", "W": "11111115151B11", "X": "11110A040A1111",
    "Y": "11110A04040404", "Z": "1F01020408101F", "0": "0E11131519110E",
    "1": "040C040404040E", "2": "0E11010204081F", "3": "1E01010E01011E",
    "4": "02060A121F0202", "5": "1F10101E01011E", "6": "0E10101E11110E",
    "7": "1F010204080808", "8": "0E11110E11110E", "9": "0E11110F01010E",
    " ": "00000000000000", ".": "00000000000C0C", ",": "00000000000408",
    ":": "000C0C000C0C00", ";": "000C0C000C0408", "-": "0000001F000000",
    "_": "0000000000001F", "/": "01010204081010", "\\": "10100804020101",
    "[": "0E08080808080E", "]": "0E02020202020E", "{": "06040408040406",
    "}": "0C04040204040C", "(": "02040808080402", ")": "08040202020408",
    "\"": "0A0A0000000000", "'": "04040000000000", "=": "00001F001F0000",
    "+": "0004041F040400", "!": "04040404040004", "?": "0E110204040004",
    "$": "040F140E051E04", "@": "0E11171517100E", "#": "0A1F0A0A1F0A00",
    "%": "19190204081313", "*": "00150E1F0E1500", "<": "02040810080402",
    ">": "08040201020408", "|": "04040404040404", "&": "0C12140C15120D",
    "^": "040A1100000000", "`": "08040000000000", "~": "00000916000000",
}
WIDTH, HEIGHT, FPS, DURATION = 960, 540, 12, 6


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def save_json(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=True) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def terminal_frame(command, stdout, number):
    """PPM replay card: real output excerpt, original layout, not screen capture."""
    pixels = bytearray(bytes((13, 19, 31)) * WIDTH * HEIGHT)

    def rect(x, y, width, height, color):
        for row in range(max(0, y), min(HEIGHT, y + height)):
            start = (row * WIDTH + max(0, x)) * 3
            end = (row * WIDTH + min(WIDTH, x + width)) * 3
            if end > start:
                pixels[start:end] = bytes(color) * ((end - start) // 3)

    def text(value, x, y, color, scale=2):
        for char in value.upper():
            glyph = bytes.fromhex(GLYPHS.get(char, GLYPHS["?"]))
            for row, bits in enumerate(glyph):
                for col in range(5):
                    if bits & (1 << (4 - col)):
                        rect(x + col * scale, y + row * scale, scale, scale, color)
            x += 6 * scale

    rect(0, 0, WIDTH, 5, (64, 219, 181))
    text("MONT / LOCAL WORKFLOW", 30, 25, (235, 242, 251), 3)
    text("REAL COMMANDS / DESIGNED REPLAY / NOT A DESKTOP CAPTURE", 30, 63, (123, 149, 177))
    text(f"0{number} / 04", 814, 25, (64, 219, 181))
    command_lines = textwrap.wrap("$ " + command, 74, replace_whitespace=False)
    for index, line in enumerate(command_lines):
        text(line, 30, 105 + index * 20, (64, 219, 181))
    lines = []
    for line in stdout.splitlines():
        lines.extend(textwrap.wrap(line, 74, replace_whitespace=False) or [""])
    top = 115 + len(command_lines) * 20
    available = max(1, (HEIGHT - 70 - top) // 18)
    for index, line in enumerate(lines[:available]):
        text(line, 30, top + index * 18, (205, 216, 232))
    footer = "COMPLETE EXACT STDOUT: TRANSCRIPT.JSON / UPPERCASE GLYPHS"
    if len(lines) > available:
        footer = f"EXCERPT: {available}/{len(lines)} WRAPPED LINES / FULL STDOUT: TRANSCRIPT.JSON"
    text(footer, 30, HEIGHT - 36, (123, 149, 177))
    return f"P6\n{WIDTH} {HEIGHT}\n255\n".encode() + pixels


class Experiment:
    def __init__(self, root, mont, ffmpeg, ffprobe):
        self.root = root
        self.mont = mont
        self.ffmpeg = ffmpeg
        self.ffprobe = ffprobe
        self.commands = []
        self.transcript = []
        self.report = {
            "status": "running", "commands": self.commands,
            "provenance": {
                "input": "Original designed replay of real commands executed in this invocation; not a desktop recording or generated testsrc.",
                "rights": "Original bitmap letterforms/layout and local dummy project content; no third-party footage, fonts, account, or desktop captured.",
                "displayChanges": "Executable shown as mont; stdout is line-wrapped, excerpted when needed, and drawn with uppercase glyphs. Exact case-sensitive stdout, argv, cwd and stdin remain in command logs.",
                "audio": "Silent; no audio content or audio-editing comparison.",
            },
            "evidenceLimits": [
                "A six-second single-recording edit, not a general editor or quality benchmark.",
                "Fresh output workspaces are not proven cold OS/GPU/filesystem caches; no cache reset or statistical significance.",
                "Each command starts a separate process; repeat means later in this invocation, not an in-process warm renderer.",
                "Timing excludes implementation effort and operator learning; tools use their own encoders and native pipelines.",
                "No publication, distribution, licensing, superiority, or rights to SDK/runtime claims.",
                "SSIM is an alignment/appearance observation, not an aesthetic or semantic-equivalence proof; inspect proof frames manually.",
            ],
        }

    def run(self, label, argv, stdin=None):
        env = os.environ.copy()
        env.pop("MONT_TOKEN", None)
        start = time.perf_counter()
        completed = subprocess.run(
            list(map(str, argv)), cwd=self.root, input=stdin,
            text=True, capture_output=True, env=env, check=False,
        )
        entry = {
            "label": label, "argv": list(map(str, argv)), "cwd": str(self.root),
            "stdin": stdin, "stdout": completed.stdout, "stderr": completed.stderr,
            "returncode": completed.returncode, "wallSeconds": time.perf_counter() - start,
        }
        self.commands.append(entry)
        save_json(self.root / "commands.json", self.commands)
        require(completed.returncode == 0, f"{label} exited {completed.returncode}; see commands.json")
        return completed.stdout

    def cli(self, label, workspace, *args):
        output = self.run(label, [self.mont, "--json", "-C", workspace, *args])
        response = json.loads(output)
        require(response.get("ok") is True, f"{label}: {response}")
        return response["result"]

    def dispatch(self, label, workspace, envelope):
        filename = label + ".json"
        save_json(self.root / filename, envelope)
        return self.cli(label, workspace, "dispatch", filename)

    def probe(self, path):
        return json.loads(self.run("probe:" + path, [
            self.ffprobe, "-v", "error", "-count_frames", "-show_streams",
            "-show_format", "-of", "json", path,
        ]))

    def media_check(self, path, width, height, duration):
        probe = self.probe(path)
        videos = [stream for stream in probe["streams"] if stream["codec_type"] == "video"]
        require(len(videos) == 1, f"{path}: expected one video stream")
        video = videos[0]
        require((video["width"], video["height"]) == (width, height), f"{path}: unexpected dimensions")
        actual = float(video.get("duration", probe["format"]["duration"]))
        require(abs(actual - duration) <= 1 / FPS + 0.01, f"{path}: duration {actual}, expected {duration}")
        require(int(video["nb_read_frames"]) == round(duration * FPS), f"{path}: unexpected frame count")
        return {"path": path, "sha256": digest(self.root / path), "probe": probe}

    def capture(self):
        operations = [
            ("init", ("init", "recording", "--project-id", "public-safe-cli-recording")),
            ("status", ("status",)),
            ("dispatch", ("dispatch", "recording-title.json")),
            ("diff", ("diff",)),
        ]
        save_json(self.root / "recording-title.json", {
            "commandId": "recording-title",
            "command": {"type": "setProjectValue", "pointer": "/title", "value": "Original local CLI workflow"},
        })
        for number, (label, args) in enumerate(operations, 1):
            self.cli("recording:" + label, "recording", *args)
            entry = self.commands[-1]
            display = shlex.join(["mont", "--json", "-C", "recording", *args])
            self.transcript.append(entry)
            (self.root / f"recording-{number}.ppm").write_bytes(terminal_frame(display, entry["stdout"], number))
        save_json(self.root / "transcript.json", self.transcript)
        (self.root / "recording.ffconcat").write_text(
            "ffconcat version 1.0\n" + "".join(f"file recording-{number}.ppm\nduration 1.5\n" for number in range(1, 5))
            + "file recording-4.ppm\n"
        )
        self.run("input:encode-designed-terminal-replay", [
            self.ffmpeg, "-hide_banner", "-nostdin", "-y", "-f", "concat", "-safe", "0",
            "-i", "recording.ffconcat", "-t", str(DURATION), "-r", str(FPS),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
            "-an", "-movflags", "+faststart", "recording.mp4",
        ])
        self.report["source"] = self.media_check("recording.mp4", WIDTH, HEIGHT, DURATION)

    def project(self, workspace="mont-workspace"):
        return json.loads((self.root / workspace / "project.json").read_text())

    def mont_render(self, phase, workspace="mont-workspace"):
        path = f"mont-{phase}.mp4"
        result = self.cli("render:mont:" + phase, workspace, "render", "--output", path, "--fps", str(FPS))
        require(result["frameCount"] == DURATION * FPS, f"{phase}: unexpected native frame count")
        require(result["durationMs"] == DURATION * 1000, f"{phase}: unexpected native duration")
        require(result["frameRate"] == FPS, f"{phase}: unexpected native frame rate")
        self.report.setdefault("montResults", {})[phase] = result
        self.report.setdefault("outputs", {})[path] = self.media_check(path, 1920, 1080, DURATION)

    def ffmpeg_render(self, phase, revised):
        initial_end = self.report["brief"]["initial"]["recording"]["sourceEndMs"] / 1000
        start, end, move = (0.5, 5.5, 1) if revised else (0, initial_end, 0)
        x, width, color = (70, 600, "0xb992ff") if revised else (40, 400, "0x40dbb5")
        filters = (
            f"color=c=black:s=1920x1080:r={FPS}:d={DURATION}[background];"
            f"[0:v]trim=start={start}:end={end},setpts=PTS-STARTPTS+{move}/TB,"
            "scale=1920:1080:flags=bicubic[clip];"
            "[background][clip]overlay=eof_action=pass:repeatlast=0[recording];"
            f"[recording]drawbox=x={x}:y=12:w={width}:h=20:color={color}:t=fill[out]"
        )
        path = f"ffmpeg-{phase}.mp4"
        self.run("render:ffmpeg:" + phase, [
            self.ffmpeg, "-hide_banner", "-nostdin", "-y", "-i", "recording.mp4",
            "-filter_complex", filters, "-map", "[out]", "-t", str(DURATION), "-r", str(FPS),
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p",
            "-an", "-movflags", "+faststart", path,
        ])
        self.report.setdefault("outputs", {})[path] = self.media_check(path, 1920, 1080, DURATION)

    def workflow(self):
        self.report["brief"] = {
            "canvas": {"width": 1920, "height": 1080, "fps": FPS, "durationMs": 6000, "background": "black"},
            "source": "recording.mp4",
            "initial": {
                "recording": {"sourceStartMs": 0, "sourceEndMs": 6000, "startMs": 0, "durationMs": 6000},
                "overlay": {"frame": {"x": 40, "y": 12, "width": 400, "height": 20}, "fill": "#40dbb5"},
            },
            "revised": {
                "recording": {"sourceStartMs": 500, "sourceEndMs": 5500, "startMs": 1000, "durationMs": 5000},
                "overlay": {"frame": {"x": 70, "y": 12, "width": 600, "height": 20}, "fill": "#b992ff"},
            },
            "preserve": "Same original recording bytes, fit to full canvas, same project title/resources and six-second overlay; no content regeneration.",
            "overlayLimit": "A native colored rectangle, not a text/caption feature claim.",
        }
        workspace = "mont-workspace"
        self.cli("project:init", workspace, "init", workspace, "--project-id", "original-cli-video")
        self.dispatch("project-title", workspace, {
            "commandId": "video-title",
            "command": {"type": "setProjectValue", "pointer": "/title", "value": "Original local CLI workflow"},
        })
        imported = self.cli("project:import", workspace, "import", "recording.mp4")
        self.report["importResult"] = imported
        require(abs(imported["durationMs"] - 6000) <= 100, "Ingested recording duration differs materially from the measured source")
        initial_end = min(6000, imported["durationMs"])
        self.report["brief"]["initial"]["recording"].update(sourceEndMs=initial_end, durationMs=initial_end)
        imported_span = next(
            span for span in self.project()["programmaticSpans"] if span["id"] == imported["spanId"]
        )
        normalized = json.loads(json.dumps(imported_span))
        normalized["placement"].update(startMs=0, durationMs=initial_end)
        normalized["capability"]["state"].update(sourceStartMs=0, sourceEndMs=initial_end)
        if normalized != imported_span:
            self.dispatch("initial-source-range", workspace, {
                "commandId": "initial-source-range",
                "command": {"type": "user_intent:programmatic_span.replace", "spans": [normalized]},
            })
        self.dispatch("create-overlay", workspace, {
            "commandId": "original-overlay",
            "command": {
                "type": "user_intent:programmatic_span.create",
                "request": {
                    "requestedId": "workflow-overlay",
                    "placement": {"startMs": 0, "durationMs": 6000, "trackId": "overlay", "layer": 10},
                    "capability": {
                        "kind": "shape.rect", "version": 1,
                        "state": {**self.report["brief"]["initial"]["overlay"], "rotationDegrees": 0, "cornerRadius": 0},
                    },
                    "interaction": {"selectable": True},
                    "producer": {"kind": "programmatic", "id": "original-video-brief", "version": "1"},
                },
            },
        })
        initial = self.project()
        save_json(self.root / "mont-initial.project.json", initial)
        self.cli("project:validate-initial", workspace, "validate")
        self.mont_render("initial")
        self.ffmpeg_render("initial", False)

        spans = {span["id"]: span for span in initial["programmaticSpans"]}
        require(imported["spanId"] in spans, "Imported video span missing from canonical project")
        require("workflow-overlay" in spans, "Created native overlay missing")
        recording = json.loads(json.dumps(spans[imported["spanId"]]))
        overlay = json.loads(json.dumps(spans["workflow-overlay"]))
        recording["placement"].update(startMs=1000, durationMs=5000)
        recording["capability"]["state"].update(sourceStartMs=500, sourceEndMs=5500)
        overlay["capability"]["state"].update(self.report["brief"]["revised"]["overlay"])
        revision = {
            "commandId": "trim-move-and-recolor",
            "command": {"type": "user_intent:programmatic_span.replace", "spans": [recording, overlay]},
        }
        self.dispatch("revision", workspace, revision)
        self.report["revisionEnvelope"] = revision
        revised = self.project()
        save_json(self.root / "mont-revised.project.json", revised)
        require(initial["title"] == revised["title"], "Revision unexpectedly changed approved title")
        require(initial.get("resources") == revised.get("resources"), "Revision unexpectedly changed source resources")
        revised_spans = {span["id"]: span for span in revised["programmaticSpans"]}
        require(set(spans) == set(revised_spans), "Revision unexpectedly added or removed spans")
        for span_id, expected in ((imported["spanId"], recording), ("workflow-overlay", overlay)):
            actual = revised_spans[span_id]
            require(actual["placement"] == expected["placement"], "Native revision lost requested placement")
            require(actual["capability"]["state"] == expected["capability"]["state"], "Native revision lost requested capability state")
        for span_id in spans.keys() - {imported["spanId"], "workflow-overlay"}:
            require(spans[span_id] == revised_spans[span_id], "Revision changed an unrelated span")
        save_json(self.root / "native-history.json", self.cli("project:history", workspace, "history"))
        save_json(self.root / "native-diff.json", self.cli("project:diff", workspace, "diff"))
        self.cli("project:validate-revised", workspace, "validate")
        self.mont_render("revised")
        self.ffmpeg_render("revised", True)
        require(
            self.report["montResults"]["initial"]["projectRevision"] != self.report["montResults"]["revised"]["projectRevision"],
            "Native edit did not advance render project revision",
        )
        self.mont_render("revised-repeat")
        self.ffmpeg_render("revised-repeat", True)
        self.cli("project:export-bundle", workspace, "export", "--bundle", "portable-bundle")
        require(self.project("portable-bundle") == revised, "Bundle changed canonical revised project")

        # Only paths made by this invocation move; retain all source artifacts.
        original = self.root / workspace
        held = self.root / "retained-original-workspace"
        source = self.root / "recording.mp4"
        held_source = self.root / "retained-recording.mp4"
        original.rename(held)
        try:
            source.rename(held_source)
            try:
                self.cli("bundle:validate-with-original-paths-absent", "portable-bundle", "validate")
                self.mont_render("portable", "portable-bundle")
            finally:
                held_source.rename(source)
        finally:
            held.rename(original)
        require(digest(source) == self.report["source"]["sha256"], "Original recording bytes changed")
        require(self.project() == revised, "Rendering unexpectedly mutated canonical project")
        self.report["preservationChecks"] = {
            "sourceSha256Unchanged": True, "titleAndResourcesUnchanged": True,
            "requestedNativePlacementAndCapabilityState": True, "unrelatedSpansUnchanged": True,
            "nativeRenderRevisionAdvanced": True, "bundleCanonicalProjectEqual": True,
            "bundleRenderedWithOriginalSourceAndWorkspacePathsAbsent": True,
            "editableWorkspace": workspace, "portableWorkspace": "portable-bundle",
            "limits": "Relocation checks pinned local portability, not an OS-level network sandbox or recovery after deleting every other file.",
        }
        for phase in ("initial", "revised"):
            self.run("measurement:ssim:" + phase, [
                self.ffmpeg, "-hide_banner", "-nostdin", "-i", f"mont-{phase}.mp4",
                "-i", f"ffmpeg-{phase}.mp4", "-filter_complex",
                f"[0:v]setpts=PTS-STARTPTS[a];[1:v]setpts=PTS-STARTPTS[b];[a][b]ssim=stats_file=ssim-{phase}.txt",
                "-an", "-f", "null", "-",
            ])
        for name in ("mont-initial", "mont-revised", "ffmpeg-initial", "ffmpeg-revised", "mont-portable"):
            for position in ("0.25", "1.25", "5.25"):
                self.run("proof:" + name + ":" + position, [
                    self.ffmpeg, "-hide_banner", "-nostdin", "-y", "-ss", position,
                    "-i", name + ".mp4", "-frames:v", "1", name + "-" + position + ".png",
                ])
        self.report["renderTimingObservations"] = [
            {"label": entry["label"], "wallSeconds": entry["wallSeconds"],
             "cacheLabel": "first project render; cold caches NOT established" if entry["label"].endswith(":initial")
             else "subsequent process; caches may be warm, not controlled"}
            for entry in self.commands if entry["label"].startswith("render:")
        ]
        self.report["executionOrder"] = "Mont then FFmpeg within initial, revised and repeat pairs; order is not randomized."
        self.report["visualReview"] = "Not automated: inspect the initial/revised/portable PNG proof frames before any public use."


def executable(value):
    found = shutil.which(value)
    if found is None:
        raise argparse.ArgumentTypeError(f"executable not found: {value}")
    return str(Path(found).resolve())


def self_test():
    require(all(len(bytes.fromhex(glyph)) == 7 for glyph in GLYPHS.values()), "font row count")
    require(all(row < 32 for glyph in GLYPHS.values() for row in bytes.fromhex(glyph)), "font width")
    frame = terminal_frame("mont status", '{"ok":true}\n', 1)
    header = f"P6\n{WIDTH} {HEIGHT}\n255\n".encode()
    require(frame.startswith(header) and len(frame) == len(header) + WIDTH * HEIGHT * 3, "PPM layout")
    require(frame == terminal_frame("mont status", '{"ok":true}\n', 1), "deterministic replay")
    require(frame != terminal_frame("mont diff", '{"ok":true}\n', 1), "real command changes frame")
    print("Passed: original bitmap font, complete PPM dimensions, deterministic transcript rendering, command-sensitive pixels.")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="New output directory outside the source checkout; retained, never uploaded")
    parser.add_argument("--mont", default=os.environ.get("MONT", "mont"))
    parser.add_argument("--ffmpeg", default="ffmpeg")
    parser.add_argument("--ffprobe", default="ffprobe")
    parser.add_argument("--self-test", action="store_true", help="Run stdlib-only deterministic replay checks, without external tools")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        return
    if args.output is None:
        parser.error("--output is required")
    root = args.output.expanduser().resolve()
    checkout = Path(__file__).resolve().parents[3]
    if root == checkout or checkout in root.parents:
        parser.error("--output must be outside the source checkout to keep all generated evidence out of commits")
    try:
        binaries = [executable(value) for value in (args.mont, args.ffmpeg, args.ffprobe)]
    except argparse.ArgumentTypeError as error:
        parser.error(str(error))
    root.mkdir(parents=True, exist_ok=False)
    experiment = Experiment(root, *binaries)
    try:
        experiment.report["versions"] = {
            "python": sys.version,
            "mont": experiment.run("version:mont", [binaries[0], "--version"]),
            "ffmpeg": experiment.run("version:ffmpeg", [binaries[1], "-version"]),
            "ffprobe": experiment.run("version:ffprobe", [binaries[2], "-version"]),
        }
        experiment.capture()
        experiment.workflow()
        experiment.report["status"] = "passed"
    except Exception as error:
        experiment.report["status"] = "failed"
        experiment.report["error"] = str(error)
        raise
    finally:
        save_json(root / "report.json", experiment.report)
    print(f"Completed local experiment: {root / 'report.json'}")


if __name__ == "__main__":
    main()
