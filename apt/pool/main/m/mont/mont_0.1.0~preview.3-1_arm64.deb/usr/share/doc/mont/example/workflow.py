#!/usr/bin/env python3
"""Exercise an installed Mont binary; all created/deleted data belongs to a tempdir."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import struct
import subprocess
import tempfile
import zlib


def png_bytes():
    """An original 1x1 blue RGBA PNG, generated with the Python standard library."""
    def chunk(kind, data):
        return struct.pack(">I", len(data)) + kind + data + struct.pack(">I", zlib.crc32(kind + data))

    return (
        b"\x89PNG\r\n\x1a\n"
        + chunk(b"IHDR", struct.pack(">IIBBBBB", 1, 1, 8, 6, 0, 0, 0))
        + chunk(b"IDAT", zlib.compress(b"\x00\x35\x70\xff\xff"))
        + chunk(b"IEND", b"")
    )


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mont", default=os.environ.get("MONT", "mont"), help="Mont executable (default: MONT or PATH)")
    args = parser.parse_args()
    binary = shutil.which(args.mont)
    if binary is None:
        parser.error("Mont executable not found; install Mont or set MONT to its executable path")
    binary = str(Path(binary).resolve())

    with tempfile.TemporaryDirectory(prefix="mont-preview-example-") as directory:
        root = Path(directory)
        source = root / "source"
        bundle = root / "bundle"
        original = root / "original.png"

        def run(workspace, *command, envelope=None):
            completed = subprocess.run(
                [binary, "--json", "-C", str(workspace), *map(str, command)],
                input=json.dumps(envelope) if envelope is not None else None,
                text=True,
                capture_output=True,
                check=False,
            )
            if completed.returncode:
                raise RuntimeError(f"mont {' '.join(map(str, command))}: {completed.stdout}{completed.stderr}")
            response = json.loads(completed.stdout)
            assert response["ok"] is True, response
            assert not completed.stderr, completed.stderr
            return response["result"]

        def set_value(workspace, key, value, command_id):
            run(workspace, "dispatch", "-", envelope={
                "commandId": command_id,
                "command": {"type": "setProjectValue", "pointer": f"/{key}", "value": value},
            })

        run(source, "init", source, "--project-id", "mont-preview-example")
        set_value(source, "title", "My standalone Mont project", "example-title")
        metadata = {"description": "A native project workflow, not a rendered video", "author": "Mont CLI example"}
        set_value(source, "metadata", metadata, "example-metadata")
        png = png_bytes()
        original.write_bytes(png)
        run(source, "asset", "add", original)
        digest = hashlib.sha256(png).hexdigest()
        assert digest in (source / "assets" / "manifest.json").read_text()
        assert digest in (source / "project.json").read_text()
        identity = json.loads((source / "mont.json").read_text())
        run(source, "validate")
        run(source, "export", "--bundle", bundle)

        # Both paths were created above, strictly inside this invocation's tempdir.
        shutil.rmtree(source)
        original.unlink()
        assert not source.exists() and not original.exists()
        run(bundle, "status")
        run(bundle, "validate")
        project = json.loads((bundle / "project.json").read_text())
        assert project["title"] == "My standalone Mont project"
        assert project["metadata"] == metadata
        assert json.loads((bundle / "mont.json").read_text()) == identity
        assert any(path.is_file() and path.read_bytes() == png for path in (bundle / "assets" / "local").rglob("*"))
        set_value(bundle, "title", "Reopened without the source", "example-reopened-title")
        assert json.loads((bundle / "project.json").read_text())["title"] == "Reopened without the source"
        assert "example-reopened-title" in json.dumps(run(bundle, "history"))
        run(bundle, "validate")

    print("Passed: native title/metadata edits, original registration, validation, bundle export, source deletion, and offline reopen/edit. Temporary data removed.")


if __name__ == "__main__":
    main()
